const date=new Date();
document.querySelector('.year').innerHTML.dateGetFullYear();
setTimeout(function(){
    ('$message').fadeOut('slow')
}, 3000);
